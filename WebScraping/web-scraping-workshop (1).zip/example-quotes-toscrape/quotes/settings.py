# -*- coding: utf-8 -*-

BOT_NAME = 'quotes'

SPIDER_MODULES = ['quotes.spiders']
NEWSPIDER_MODULE = 'quotes.spiders'

ROBOTSTXT_OBEY = True

FEED_FORMAT = "csv"
FEED_URI = "quotes.csv"
