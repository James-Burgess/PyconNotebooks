# -*- coding: utf-8 -*-

BOT_NAME = 'lawyers'

SPIDER_MODULES = ['lawyers.spiders']
NEWSPIDER_MODULE = 'lawyers.spiders'

# Need to set this to False otherwise image download doesn't work.
#
ROBOTSTXT_OBEY = False

FEED_FORMAT = "json"
FEED_URI = "lawyers.json"

# See http://scrapy.readthedocs.org/en/latest/topics/item-pipeline.html
#
ITEM_PIPELINES = {
   # Default images pipeline.
   #
   'scrapy.pipelines.images.ImagesPipeline': 1
}
IMAGES_STORE = 'images/'

CONCURRENT_REQUESTS = 2
