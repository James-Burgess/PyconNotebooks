# -*- coding: utf-8 -*-
import scrapy
from bs4 import BeautifulSoup
import string

class LawyerSpider(scrapy.Spider):
    name = 'Lawyer'
    allowed_domains = ['www.webberwentzel.com']

    def start_requests(self):
        base_url = "http://www.webberwentzel.com/wwb/content/en/ww/ww-our-people?as_request=as_results&character="

        for url in [base_url + letter for letter in string.ascii_uppercase]:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        for lawyer in response.css("#main_content_column"):
            table = lawyer.css("div:nth-child(5) > div.profile_info > table")

            image_url = response.urljoin(lawyer.css("div:nth-child(5) > div:nth-child(1) > div > img::attr(src)").extract_first())

            # name          - replace '&nbsp;' (converted to Unicode) with ' '.
            # practice      - strip whitespace.
            #
            # image_urls    - must be a list (for pipeline).
            #
            yield {
                'name':         lawyer.css("div.profile_name::text").extract_first().replace('\xa0', ' '),
                'position':     table.css("tr:nth-child(1) > td:nth-child(2)::text").extract_first(),
                'practice':     table.css("tr:nth-child(3) > td:nth-child(2)::text").extract_first().replace('\n', '').strip(),
                'office':       table.css("tr:nth-child(5) > td:nth-child(2)::text").extract_first(),
                'telephone':    table.css("tr:nth-child(7) > td:nth-child(2)::text").extract_first(),
                'email':        table.css("tr:nth-child(9) > td:nth-child(2) > a::text").extract_first(),
                'image_urls':   [image_url],
            }

        for url in response.css("div.psr_profile > a::attr(href)").extract():
            yield scrapy.Request(response.urljoin(url))
